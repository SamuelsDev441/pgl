import pygame


class type:
    if pygame.event.Event.type == pygame.QUIT:
        pygame.QUIT()

        if pygame.event.Event.type == pygame.K_a:
            key = 'a'

        if pygame.event.Event.type == pygame.K_b:
            key = 'b'

        if pygame.event.Event.type == pygame.K_c:
            key = 'c'
