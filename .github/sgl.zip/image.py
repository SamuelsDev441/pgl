import pygame


def add(imagepath):
    pygame.image.load(imagepath)
