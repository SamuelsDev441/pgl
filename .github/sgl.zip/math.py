def integral(num):
    intg = 1 // (num + 1) * num
    print(num)


def div(num, num2):
    ans = 0
    if num > num2:
        ans = num / num2
    if num < num2:
        if ans == 0.5:
            ans = '1 / 2'
            return ans
